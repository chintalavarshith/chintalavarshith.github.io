<?php 
// replace *** with your database credentials
$host=$_ENV["host"];
$user=$_ENV["username"];
$project=$_ENV["project"];
$ps=$_ENV["password"];
?>
